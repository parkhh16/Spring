package com.ssafy.mvc.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ssafy.mvc.model.dto.User;

import jakarta.servlet.http.HttpSession;

@Controller
public class MyPageController {

	User loginUser = new User("ssafy", "1234", "김싸피", "ssafy01@ssafy.com", 20, "user.png");
	
	private ResourceLoader resourceLoader;
	
	public MyPageController(ResourceLoader resourceLoader) {
		this.resourceLoader = resourceLoader;
	}
	
	@GetMapping("/myPageForm")
	public String myPageForm(HttpSession session, Model model) {
								// session			// request
		
		
		session.setAttribute("loginUser", loginUser);
		
		
		
		return "/myPageForm";
	}
	
	@PostMapping("/myPageUpdate")
	public String myPageUpdate(@ModelAttribute User user,
			@RequestParam("file") MultipartFile file, Model model,
			HttpSession session) throws IllegalStateException, IOException {
		
		
		
		loginUser = (User) session.getAttribute("loginUser");
		
		loginUser.setPassword(user.getPassword());
		
//		System.out.println(user);
		// 파일이 null이 아닐때만 파일 저장하고 set해줌.
		if(file != null && file.getSize() > 0) {
			String fileName = file.getOriginalFilename();
			Resource resource = resourceLoader.getResource("classpath:/static/img");
			
			file.transferTo(new File(resource.getFile(), fileName));
			loginUser.setImg(fileName);
			
		}
		
		return "/myPageForm";
		
	}
	
	
	
}
