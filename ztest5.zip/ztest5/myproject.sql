drop database if exists abc;
create database if not exists abc;
use ssafy_test; -- ssafy_test 데이터베이스를 사용
Create table member(
	userid VARCHAR(50) PRIMARY KEY,
	userpw VARCHAR(50) NOT NULL,
	name VARCHAR(50) NOT NULL
);
Insert into member (userid, userpw, name)
values ('ssafy','1234','hyunho');

select * from member