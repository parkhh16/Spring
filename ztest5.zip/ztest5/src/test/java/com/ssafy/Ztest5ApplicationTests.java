package com.ssafy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ztest5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
