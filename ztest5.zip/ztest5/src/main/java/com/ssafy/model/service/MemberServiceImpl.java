package com.ssafy.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dao.MemberDAO;
import com.ssafy.model.dto.MemberDTO;
@Service
public class MemberServiceImpl implements MemberService {
	MemberDAO dao;
	
//	public MemberServiceImpl(MemberDAO dao) {
//		this.dao = dao;
//	}
	public MemberDAO getDao() {
		return dao;
	}
	@Autowired
	public void setDao(MemberDAO dao) {
		this.dao = dao;
	}
	@Override
	public void signin(MemberDTO dto) {
		dao.insert(dto);
	}
}
