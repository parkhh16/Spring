package com.ssafy.model.service;

import com.ssafy.model.dto.MemberDTO;

public interface MemberService {
	void signin(MemberDTO dto);
}
