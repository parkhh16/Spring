package com.ssafy.model.dao;


import com.ssafy.model.dto.MemberDTO;

public interface MemberDAO {
	void insert(MemberDTO dto);
}
