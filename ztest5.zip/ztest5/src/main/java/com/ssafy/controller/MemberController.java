package com.ssafy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.model.dto.MemberDTO;
import com.ssafy.model.service.MemberService;
// 신호등 :  클라이언트 (이벤트발생) -> url 분석 누가처리할것인지 분류 호출  
@Controller
public class MemberController {
	MemberService service;
	
	public MemberController() {
	}
	@Autowired // 생성자가 1개뿐이면 생략가능
	public MemberController(MemberService service) {
		this.service = service;
	}

//	//    /signin?userid=ssafy&userpw=1234&name=minkyu
//	@PostMapping("/signin")
//	@RequestMapping(value="/signin", method=RequestMethod.POST)
//	public String doSignin(Model model, @RequestParam("userid") String userid, 
//					@RequestParam("userpw") String userpw, @RequestParam("name") String name) {
//		MemberDTO dto = new MemberDTO(userid, userpw, name);
//		service.signin(dto);
//		System.out.println("회원가입 성공");
//		
//		model.addAttribute("dto", dto);
//		return "result"; // forward 기본 이동방식
//	}
	
	@RequestMapping(value="/signin", method=RequestMethod.POST)
	public String doSignin(Model model, @ModelAttribute MemberDTO dto) {
//		MemberDTO dto = new MemberDTO(userid, userpw, name);
		service.signin(dto);
		System.out.println("회원가입 성공");
		
		model.addAttribute("dto", dto);
		return "result"; // forward 기본 이동방식
	}
	
	@GetMapping({"/", "/index"})
//	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index() {
		return "index";
	}
	
//	@GetMapping("/signinform")
//	public String s() {
//		return "signinform"; //      /WEB-INF/view/signinform.jsp
//	}
	@GetMapping("/signinform") // 리턴타입이 void면 uri 값이 뷰네임이 된다
	public void s() {
		return; //      /WEB-INF/view/signinform.jsp
	}
	
	
}
//<property name="prefix" value="/WEB-INF/view/"></property>
//<property name="suffix" value=".jsp"></property>
















