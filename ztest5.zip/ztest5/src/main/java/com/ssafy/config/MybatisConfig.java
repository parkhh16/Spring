package com.ssafy.config;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@MapperScan(basePackages = "com.ssafy.model.dao")//dao의 풀패키지명
public class MybatisConfig {
	
}

//private static SqlSessionFactory factory;//factory가 지금은 null sqlsessionfactory는 인터페이스
//
//static {
//	//factory내부 만들기
//	String resource = "mybatis-config.xml";
//	try(InputStream inputSream = Resources.getResourceAsStream(resource)){
//		factory = new SqlSessionFactoryBuilder().build(inputSream);
//		System.out.println("factory완성");
//	} catch(IOException e) {
//		e.printStackTrace();
//		System.out.println("factory실패");
//	}
//	
//}
//
//
//public static SqlSessionFactory getFactory() {
//	return factory;
//}