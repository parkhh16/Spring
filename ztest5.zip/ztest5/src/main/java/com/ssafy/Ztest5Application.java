package com.ssafy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ztest5Application {

	public static void main(String[] args) {
		SpringApplication.run(Ztest5Application.class, args);
	}

}
